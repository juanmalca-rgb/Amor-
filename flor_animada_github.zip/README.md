# Flor animada 🌻

Página web inspirada en una animación de flor hecha con partículas.

Archivos:
- index.html
- style.css
- script.js

Para GitHub Pages: sube los tres archivos al repositorio y activa Pages desde Settings → Pages → Deploy from a branch → main → /(root).
