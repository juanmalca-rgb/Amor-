const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");
let W,H,dpr,particles=[],petals=[],stars=[],running=true,time=0;

function resize(){
  dpr=Math.min(devicePixelRatio||1,2);
  W=innerWidth; H=innerHeight;
  canvas.width=W*dpr; canvas.height=H*dpr;
  canvas.style.width=W+"px"; canvas.style.height=H+"px";
  ctx.setTransform(dpr,0,0,dpr,0,0);
  createScene();
}
function rand(a,b){return Math.random()*(b-a)+a}
function createScene(){
  particles=[]; petals=[]; stars=[];
  const cx=W/2, cy=H*.38;
  // Golden ground
  for(let i=0;i<Math.min(1800, W*2.5);i++){
    const x=rand(0,W), y=rand(H*.48,H);
    particles.push({x,y,s:rand(.4,1.7),a:rand(.15,.85),tw:rand(0,7)});
  }
  // Sunflower petal particles
  const count=Math.min(2600,Math.max(900,W*3.2));
  for(let i=0;i<count;i++){
    const t=i/count*Math.PI*2*9 + rand(-.08,.08);
    const ring=rand(.75,1.12);
    const r=Math.min(W,H)*.15*ring;
    const cx2=cx+Math.cos(t)*r*(1+0.18*Math.sin(9*t));
    const cy2=cy+Math.sin(t)*r*(1+0.18*Math.sin(9*t));
    petals.push({
      x:cx2,y:cy2,baseX:cx2,baseY:cy2,
      size:rand(1.1,3.2),phase:rand(0,6.28),gold:Math.random()<.55
    });
  }
  // Dark center
  for(let i=0;i<700;i++){
    const a=rand(0,Math.PI*2), r=Math.sqrt(Math.random())*Math.min(W,H)*.075;
    petals.push({x:cx+Math.cos(a)*r,y:cy+Math.sin(a)*r,baseX:cx+Math.cos(a)*r,baseY:cy+Math.sin(a)*r,size:rand(1,3),phase:rand(0,6.28),gold:false,center:true});
  }
  for(let i=0;i<100;i++) stars.push({x:rand(0,W),y:rand(0,H),s:rand(.5,2.5),a:rand(.2,.8)});
}
function glowCircle(x,y,r,color,alpha=1){
  const g=ctx.createRadialGradient(x,y,0,x,y,r);
  g.addColorStop(0,color.replace("ALPHA",alpha));
  g.addColorStop(1,color.replace("ALPHA","0"));
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
}
function draw(){
  if(!running){requestAnimationFrame(draw);return}
  time+=.016;
  ctx.fillStyle="#010101";ctx.fillRect(0,0,W,H);

  // atmospheric glow
  glowCircle(W/2,H*.38,Math.min(W,H)*.38,"rgba(255,180,0,ALPHA)",.10);

  // stars / golden dust
  for(const s of stars){
    ctx.globalAlpha=s.a*(.55+.45*Math.sin(time*2+s.x));
    ctx.fillStyle="#ffd92f";ctx.fillRect(s.x,s.y,s.s,s.s);
  }
  for(const p of particles){
    const yy=p.y+Math.sin(time*1.4+p.tw)*2;
    ctx.globalAlpha=p.a;
    ctx.fillStyle=Math.random()<.08?"#fff2ad":"#d8ad18";
    ctx.fillRect(p.x,yy,p.s,p.s);
  }

  // flower shadow
  ctx.globalAlpha=.28;ctx.fillStyle="#f3c52b";
  ctx.beginPath();ctx.ellipse(W/2,H*.53,Math.min(W,H)*.27,Math.min(W,H)*.035,0,0,Math.PI*2);ctx.fill();

  // petals
  for(const p of petals){
    const drift=Math.sin(time*1.5+p.phase)*1.8;
    ctx.globalAlpha=.75+.2*Math.sin(time*2+p.phase);
    ctx.fillStyle=p.center?(Math.random()<.45?"#160700":"#3b1300"):(p.gold?"#ffe500":"#ffd000");
    ctx.fillRect(p.x+drift,p.y+Math.cos(time+p.phase)*1.5,p.size,p.size);
  }

  // center glow
  glowCircle(W/2,H*.38,Math.min(W,H)*.11,"rgba(255,70,0,ALPHA)",.28);
  ctx.globalAlpha=1;
  requestAnimationFrame(draw);
}
canvas.addEventListener("pointerdown",(e)=>{
  for(let i=0;i<35;i++){
    particles.push({x:e.clientX+rand(-35,35),y:e.clientY+rand(-35,35),s:rand(1,3),a:1,tw:rand(0,7)});
  }
});
document.getElementById("play").onclick=()=>{
  running=!running;
  document.getElementById("play").textContent=running?"▶":"Ⅱ";
};
document.getElementById("fullscreen").onclick=()=>{
  if(!document.fullscreenElement) document.documentElement.requestFullscreen?.();
  else document.exitFullscreen?.();
};
document.getElementById("reveal").onclick=()=>{
  document.querySelector(".message").style.opacity=".35";
  setTimeout(()=>document.querySelector(".message").style.opacity="1",700);
};
resize();
addEventListener("resize",resize);
draw();
